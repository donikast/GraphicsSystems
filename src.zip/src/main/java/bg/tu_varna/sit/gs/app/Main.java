package bg.tu_varna.sit.gs.app;


public class Main {
    public static void main(String[] args) {
        App app = new App(800, 600, "Demo");
        app.run();
    }
}